from ultralytics import YOLOv10
import torch
import os
os.environ['CUDA_LAUNCH_BLOCKING'] = '1'
torch.backends.cudnn.enable =True
torch.backends.cudnn.benchmark = True
if __name__ == '__main__':

    print(torch.version.cuda)
    model = YOLOv10(r"ultralytics/cfg/models/v10/yolov10n.yaml")

    model.train(data=r'ultralytics/cfg/datasets/coco128.yaml',epochs=300,batch=12,imgsz=640,workers=0)
