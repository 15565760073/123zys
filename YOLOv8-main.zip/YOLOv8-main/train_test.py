import torch
# print(torch.cuda.is_available())
import cv2
import os
from ultralytics import YOLO
from torch.optim import AdamW
import datetime

if __name__ == '__main__':

    # #训练模型
    model = YOLO(r"ultralytics\cfg\models\v8\yolov8.yaml")
    results = model.train(data=r'ultralytics\cfg\datasets\coco128.yaml',epochs=200,workers=0,batch=12)

    #results = model("C:/Users/www28/Desktop/Thesis reproduction/ultralytics-yolov8/ultralytics/datasets/coco/images/val2017/000000079651.jpg")  # 对图像进行预测


